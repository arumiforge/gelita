# GELITA — Current image prompts

Direction: stylized 3D; Jaka uses reference.01 and a red scarf. Historical prompts are archived. Audio unchanged.

## reference.01 — Jaka — lembar karakter

File: assets/referensi/reference.01.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.01. Follow the brief below.

REFERENCE USE
Use the attached reference image to preserve the subject identity, costume, proportions, materials and composition described below. Do not combine it with a conflicting costume variant.

VISUAL BRIEF
Create a square character reference sheet of Jaka, an approximately 11-year-old Javanese boy with warm skin, large brown eyes, tousled dark-brown hair and an upward cowlick. Preserve the supplied design: cream short-sleeved shirt, red scarf, dark-brown knee-length shorts, brown belt, orange-brown batik cloth tied at the waist, brown sandals, and a brown leather backpack with brass buckles. Left: one large three-quarter portrait. Upper right: eight expressions—happy, enthusiastic, calm, surprised, determined, worried, thinking, and amazed. Lower right: four full-body views—front, side, back, and right three-quarter. Include separate close-ups of hair, scarf, backpack, batik cloth and sandals, plus palette swatches. Use a warm cream studio background, consistent lighting, clear spacing, and no written labels. This is the original red-scarf variant, not the later lurik-and-iket design.

COMPOSITION AND DELIVERY
Target production canvas: 2048 × 2048 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.02 — Mbah Kedu — avatar

File: assets/referensi/reference.02.webp

Style review: Sesuai gaya

Create one square finished GELITA game reference asset: Mbah Kedu avatar, a kind elderly Javanese man with white moustache and short beard, traditional brown batik headwrap and cream/brown clothing, smiling gently, bust portrait within an ornate round gold medallion. Premium stylized 3D animated family adventure movie render, softly rounded features, realistic cloth and warm gold materials, warm cinematic lighting. Entire medallion visible with padding. Transparent exterior. No lettering, no watermark. This companion belongs to a game whose child hero wears a red scarf; do not put a red scarf on the elder.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.03 — Jaka — avatar syal merah

File: assets/referensi/reference.03.webp

Style review: Sesuai gaya

Use the attached Jaka character sheet as identity reference. Create ONE square transparent bust avatar of the SAME approximately 11-year-old Javanese boy: tousled dark brown hair and cowlick, large brown eyes, warm tan skin, cream short sleeve shirt, unmistakable RED SCARF, brown leather backpack straps. Friendly happy expression. Premium stylized 3D animated adventure movie rendering, dimensional skin and cloth, warm soft lighting. No blue vest, no headwrap, no striped lurik. Preserve reference face and hair. Entire head and shoulders within frame, no text, no watermark.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.04 — Lembah magis saat senja

File: assets/referensi/reference.04.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.04. Follow the brief below.

REFERENCE USE
Use the attached reference image to preserve the subject identity, costume, proportions, materials and composition described below. Do not combine it with a conflicting costume variant.

VISUAL BRIEF
Create a wide fantasy panorama inspired by the Kedu plain at sunset. View from a high hillside. A large tree and foliage frame the upper left; a glowing amber lantern and stone footpath occupy the lower left. Across the middle distance, green rice fields, traditional village roofs, reflective water and a distant temple lead toward layered volcanic mountains and blue mist. Low sun near the left horizon, small moon at the upper right, orange-purple-blue sky. Warm village lights and subtle fireflies. Leave useful open space for a landing-page interface; do not include characters, text or buttons.

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.05 — Cahaya Kedu — latar prolog

File: assets/referensi/reference.05.webp

Style review: Sesuai gaya

Create one wide 16:9 GELITA prologue scene in premium stylized 3D animated adventure movie style. Use attached character sheet only as identity reference for Jaka: same 11-year-old Javanese boy, tousled brown hair, cream shirt, RED SCARF, dark brown shorts, batik waist cloth, sandals, leather backpack. Jaka at right foreground holding a glowing brass lantern, full body visible. Behind him a magical Kedu valley, terraced rice fields, twin volcanoes, Javanese village and distant stone temple under warm dawn light, thin luminous mist. Leave left half and lower central area calm for future UI overlays. Rich dimensional materials and cinematic depth, no gouache or flat painting. No text, labels, dialogue panels, watermark. This is an illustrative fantasy landscape, not a measured map.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.06 — Jalur cahaya menuju candi

File: assets/referensi/reference.06.webp

Style review: Sesuai gaya

Create one wide 16:9 reference background for GELITA, a premium stylized 3D animated Javanese adventure game. A sweeping golden Kedu valley with terraced rice fields, tropical trees, distant twin volcanoes and a stone Central Javanese temple on a hill. A magical softly glowing winding path leads from foreground towards the temple. Rich dimensional foliage, sculpted terrain, warm cinematic sunset, atmospheric depth, family-friendly wonder. No people, no text, no watermark, no painted brush texture. Keep central foreground uncluttered for game UI; temple and mountains fully visible. Illustrative fantasy landscape, not a factual measured map.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.07 — Gerbang pohon tua

File: assets/referensi/reference.07.webp

Style review: Sesuai gaya

Create ONE wide 16:9 background reference for GELITA in premium stylized 3D animated adventure movie style. Ancient Central Javanese stone gateway nestled between enormous old tropical trees with twisting roots, mossy stone path leading through the open gateway, shafts of warm late-afternoon golden sunlight, hints of mist and distant green hills. Inviting magical atmosphere appropriate for children. Dimensional sculpted bark, stone and foliage, cinematic depth, no brush painting. No characters, no letters or signs, no watermark. Keep path readable and quiet central space for future game dialogue.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.08 — Diorama wilayah Kedu

File: assets/referensi/reference.08.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.08. Follow the brief below.

REFERENCE USE
Use the attached reference image to preserve the subject identity, costume, proportions, materials and composition described below. Do not combine it with a conflicting costume variant.

VISUAL BRIEF
Create a floating-landscape diorama seen from a high three-quarter isometric angle. Show the complete rocky island edge. Tall volcanic mountains at the back, a blue lake on the left slope, forest, terraced rice fields, a winding river flowing toward the foreground, tiny villages, stone bridges, stepped temples and interconnected earthen paths. Detailed miniature materials, warm golden-hour lighting from upper left. Transparent outside the island. No labels, pins, administrative boundaries or interface. This is a fantasy diorama, not an accurate geographic map.

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.09 — Logo GELITA landscape

File: assets/referensi/reference.09.webp

Style review: Sesuai gaya

Create ONE transparent horizontal GELITA game logo reference, a polished dimensional 3D gold logotype with subtle turquoise inlays and restrained Central Javanese ornamental flourishes. Exact text: GELITA. All six letters clearly readable and correctly spelled. Integrate a small glowing brass lantern tastefully above or beside the lettering without replacing any letter. Warm gold bevels, rich dark navy recesses, premium stylized adventure game aesthetic, balanced compact composition, whole logo inside canvas with generous clear margins. No tagline, no other words, no background rectangle, no watermark. Wide approximately 16:7 composition.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.10 — Tombol mulai

File: assets/referensi/reference.10.webp

Style review: Sesuai gaya

Create ONE isolated GELITA game start button reference, transparent background. Wide horizontal capsule button with dimensional dark navy enamel center and polished beveled gold frame, small restrained Javanese gold ornamental accents at ends. Exact centered text: MULAI. Large legible raised gold serif letters. Premium stylized 3D family adventure game interface, warm highlights, crisp balanced silhouette, generous transparent padding all around, no extra words or icons, no watermark. Approximately 10:3 button shape on a wide canvas.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.11 — Medali kopi dan daun

File: assets/referensi/reference.11.webp

Style review: Sesuai gaya

Create ONE square transparent reference reward medallion for GELITA. Entire ornate circular polished GOLD frame visible with clear padding, dark navy enamel inner background. At center a sculptural cluster of ripe RED COFFEE CHERRIES, glossy green coffee leaves and a single brown-gold leaf, visually botanical coffee rather than grapes. Premium stylized 3D adventure game collectible, dimensional modeled materials, warm soft highlights, restrained elegant Javanese ornamental motifs. No text, no numbers, no watermark. Transparent exterior around the medallion.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.12 — Judul Peta Wilayah Kedu

File: assets/referensi/reference.12.webp

Style review: Sesuai gaya

Create ONE transparent horizontal decorative title graphic for GELITA map screen. EXACT text in two centered lines: first line 'PETA WILAYAH', second line 'KEDU'. Clearly legible dimensional embossed warm gold serif lettering, dark brown extruded sides and soft shadow, restrained carved Javanese wood and gold flourishes framing the title. Premium stylized 3D adventure game art matching golden lantern and navy game interface. All letters and ornaments entirely visible with generous transparent padding. No other text, no watermark, no background panel. Approximately 1.8:1 overall canvas.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.13 — Jaka — sprite petualang

File: assets/referensi/reference.13.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.13. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Use the supplied red-scarf Jaka sheet as the identity reference. Create one full-body sprite, three-quarter view facing screen right, standing and raising his right hand in a friendly greeting. Preserve his face, hair, cream shirt, red scarf, leather backpack, dark shorts, waist batik and sandals. Consistent child proportions and lighting. One pose only in this image. Produce pointing, thinking, celebrating and neutral poses in separate subsequent images, preserving canvas scale and foot position. Do not use the blue-waistcoat avatar costume.

COMPOSITION AND DELIVERY
Target production canvas: 1024 × 1536 pixels; aspect ratio 2:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.14 — Mbah Kedu — narator

File: assets/referensi/reference.14.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.14. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Use the supplied Mbah Kedu avatar as the face and head-wrap reference. Extend him to a waist-up narrator character in dark-brown traditional clothing. Preserve his white hair, short moustache and beard, wrinkles and gentle age characteristics. Friendly smile and one open hand explaining something. Soften rendering to fit the character artwork without making him younger. One pose only. Body and clothing below the avatar crop are a design extension, not details visible in the source.

COMPOSITION AND DELIVERY
Target production canvas: 1024 × 1536 pixels; aspect ratio 2:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.15 — Pendukung — penjaga desa

File: assets/referensi/reference.15.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.15. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Design one new adult village guide for the GELITA story world, with a face clearly different from Jaka and Mbah Kedu. Simple cream and brown clothing, a restrained batik accent and a small cloth bag. Friendly expression, full-body three-quarter pose with an open welcoming hand. Soft illustrated character style consistent with the selected reference sheet. This is a proposed supporting character, not someone identified in the uploaded images. Transparent background.

COMPOSITION AND DELIVERY
Target production canvas: 1024 × 1536 pixels; aspect ratio 2:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.16 — Logo simbol lentera

File: assets/referensi/reference.16.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.16. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Derive a standalone emblem from the lantern in the supplied GELITA logo. One antique-gold lantern with a pointed cap, warm amber glass and flame, two simple decorative curls and a small turquoise gemstone. Compact readable silhouette, centred square composition. No letters, wordmark, subtitle or ribbon. Transparent background.

COMPOSITION AND DELIVERY
Target production canvas: 1024 × 1024 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.17 — Speaker aktif

File: assets/referensi/reference.17.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.17. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a sound-on interface icon: one large gold speaker with two curved sound waves at right. Centre it on a dark navy circular button with a thin gold rim and subtle top highlight. Keep line weights consistent and the symbol readable at 32–48 pixels. No lettering or ornate microdetails.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.18 — Speaker nonaktif

File: assets/referensi/reference.18.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.18. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a sound-off interface icon matching the sound-on icon exactly in geometry, scale and material. Gold speaker with a clear diagonal mute stroke instead of sound waves. Dark navy circular button, thin gold rim, subtle top highlight. No text.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.19 — Bahasa English

File: assets/referensi/reference.19.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.19. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create an English-language selection button matching the navy-and-gold circular interface family. Leave a clean central area reserved for the exact uppercase label “EN”, added separately as editable text. No national flag. Consistent ring thickness and readable at small display sizes.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.20 — Bahasa Indonesia

File: assets/referensi/reference.20.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.20. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create an Indonesian-language selection button with exactly the same geometry and materials as the English button. Leave a clean central area reserved for the exact uppercase label “ID”, added separately as editable text. No national flag. Consistent size and ring thickness.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.21 — Masuk layar penuh

File: assets/referensi/reference.21.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.21. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create an enter-fullscreen icon: four gold right-angle corner marks pointing outward, arranged symmetrically around an empty centre. Large simple symbol on the same dark navy circular button with thin gold rim as the other controls. No text.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.22 — Keluar layar penuh

File: assets/referensi/reference.22.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.22. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create an exit-fullscreen icon: four gold right-angle corner marks pointing inward to indicate returning to normal view. Preserve the size, line weight, circular navy base and gold rim of the enter-fullscreen control. No text.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.23 — Kembali

File: assets/referensi/reference.23.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.23. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a back-navigation icon: one clear gold left-pointing arrow with a short shaft and readable arrowhead, centred on the shared navy circular base and thin gold rim. Match the next-navigation control's dimensions exactly. No text.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.24 — Selanjutnya

File: assets/referensi/reference.24.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.24. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a next-navigation icon: one clear gold right-pointing arrow, the mirrored geometric counterpart of the back-navigation icon. Same short shaft, arrowhead, line weight, navy circular base and thin gold rim. No text.

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.25 — Login — lentera penyambut

File: assets/referensi/reference.25.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.25. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a 16:9 login-page illustration: a blue-evening Kedu valley with a tree and glowing gold lantern within the left third, a small stone path toward an illuminated village, distant misty mountains. Keep the main scenic detail in the left 55 percent. Reserve the right 45 percent as a quiet dark teal gradient for a separate HTML login form. Amber light guides attention toward the centre. No characters, logos, words, email fields, password fields or buttons.

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## reference.26 — Daftar — awal petualangan

File: assets/referensi/reference.26.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reference.26. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a 16:9 registration-page illustration using the old tree and mossy gateway references. Gateway at left, winding stone path into a warmly lit valley, green plants and a few subtle fireflies. Reserve the right 45 percent as calm dark teal space for a separate tall registration form. Match the login illustration's palette and form placement. No characters, text, logos, fields or buttons.

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

Negative: Do not include watermarks, signatures, unintended text, extra limbs or fingers, duplicate faces, cropped key features, blurry edges, neon colours, visual clutter, or a checkerboard pattern pretending to be transparency.

---

## challenge.item.tmg-1-01 — Gunung Sindoro dan Sumbing

File: assets/tantangan/challenge.item.tmg-1-01.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-1-01. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Mount Sindoro and Mount Sumbing above cultivated foothills under a clear sky. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-1-03 — Candi Pringapus

File: assets/tantangan/challenge.item.tmg-1-03.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-1-03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the actual front facade of Candi Pringapus. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-1-04 — Kuda Lumping

File: assets/tantangan/challenge.item.tmg-1-04.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-1-04. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a kuda lumping dancer holding a colourful woven bamboo hobby horse. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-3-a03 — Butir padi hangus

File: assets/tantangan/challenge.item.tmg-3-a03.webp

Style review: Perlu tinjau

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-3-a03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text blackened charred rice grains, archaeological objects. Keep the subject clear in the central horizontal band. No labels, captions or clues to whether the associated statement is true.

COMPOSITION AND DELIVERY
Target production canvas: 480 × 360 pixels; aspect ratio 4:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-3-b03 — Arca Buddha duduk

File: assets/tantangan/challenge.item.tmg-3-b03.webp

Style review: Perlu tinjau

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-3-b03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a seated stone Buddha statue. Keep the subject clear in the central horizontal band. No labels, captions or clues to whether the associated statement is true.

COMPOSITION AND DELIVERY
Target production canvas: 480 × 360 pixels; aspect ratio 4:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-3-c03 — Biji kopi sangrai

File: assets/tantangan/challenge.item.tmg-3-c03.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-3-c03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text brown roasted coffee beans. Keep the subject clear in the central horizontal band. No labels, captions or clues to whether the associated statement is true.

COMPOSITION AND DELIVERY
Target production canvas: 480 × 360 pixels; aspect ratio 4:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-02 — Biji kopi

File: assets/tantangan/challenge.item.tmg-4-02.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-02. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a small handful of coffee beans. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-03 — Kuda kepang bambu

File: assets/tantangan/challenge.item.tmg-4-03.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a colourful woven bamboo hobby horse without a dancer. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-04 — Ikan uceng

File: assets/tantangan/challenge.item.tmg-4-04.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-04. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text several small slender uceng fish. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-06 — Arca Nandi

File: assets/tantangan/challenge.item.tmg-4-06.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-06. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a seated stone Nandi bull sculpture. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-09 — Angklung

File: assets/tantangan/challenge.item.tmg-4-09.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-09. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a bamboo angklung instrument. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-10 — Ondel-ondel

File: assets/tantangan/challenge.item.tmg-4-10.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-10. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a miniature ondel-ondel figure. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-11 — Perahu pinisi

File: assets/tantangan/challenge.item.tmg-4-11.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-11. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a pinisi sailing boat with sails. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.tmg-4-12 — Sasando

File: assets/tantangan/challenge.item.tmg-4-12.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.tmg-4-12. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a sasando instrument. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.tmg-4.scene — Pasar Budaya Temanggung

File: assets/tantangan/challenge.tmg-4.scene.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.tmg-4.scene. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a village hall courtyard and cultural market below Sindoro and Sumbing; three empty shelf rows at approximately 27, 61 and 93 percent of image height. Keep all shelves empty: interactive objects will be placed by the application. Do not embed targets, decoys, text or buttons in the scene.

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-1-01 — Stupa Borobudur

File: assets/tantangan/challenge.item.mgl-1-01.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-1-01. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a perforated Borobudur upper-terrace stupa with the main stupa in the background. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-1-02 — Penari Topeng Ireng

File: assets/tantangan/challenge.item.mgl-1-02.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-1-02. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a Topeng Ireng dancer wearing a colourful feather kuluk headdress. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-1-03 — Candi Mendut

File: assets/tantangan/challenge.item.mgl-1-03.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-1-03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the real front facade and entrance stairs of Candi Mendut. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a01 — Stupa berlubang

File: assets/tantangan/challenge.item.mgl-4-a01.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a01. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a miniature perforated stupa. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a02 — Kuluk Topeng Ireng

File: assets/tantangan/challenge.item.mgl-4-a02.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a02. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a colourful Topeng Ireng feather kuluk headdress. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a03 — Getuk

File: assets/tantangan/challenge.item.mgl-4-a03.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text three-colour getuk on a banana leaf. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a04 — Kendil gerabah

File: assets/tantangan/challenge.item.mgl-4-a04.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a04. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a reddish-brown clay kendil pot. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a05 — Kuda kepang bambu

File: assets/tantangan/challenge.item.mgl-4-a05.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a05. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a woven bamboo hobby horse. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a06 — Manisan carica dalam stoples

File: assets/tantangan/challenge.item.mgl-4-a06.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a06. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a clear jar of preserved carica fruit. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a07 — Dadak merak Reog

File: assets/tantangan/challenge.item.mgl-4-a07.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a07. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a Reog Ponorogo dadak merak mask and peacock feather structure. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a08 — Angklung

File: assets/tantangan/challenge.item.mgl-4-a08.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a08. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a bamboo angklung instrument. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a09 — Bakpia

File: assets/tantangan/challenge.item.mgl-4-a09.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a09. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text several bakpia pastries. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.mgl-4-a10 — Panci logam

File: assets/tantangan/challenge.item.mgl-4-a10.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.mgl-4-a10. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a metal cooking pot. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.mgl-4.scene — Galeri Budaya Magelang

File: assets/tantangan/challenge.mgl-4.scene.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.mgl-4.scene. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a Magelang cultural gallery or pendapa with two rows of empty wooden display tables; stupa forms and Tidar hill in the background. Keep all shelves empty: interactive objects will be placed by the application. Do not embed targets, decoys, text or buttons in the scene.

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-1-05 — Telaga Warna

File: assets/tantangan/challenge.item.wnb-1-05.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-1-05. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the green-turquoise Telaga Warna lake. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-1-06 — Matahari Terbit di Sikunir

File: assets/tantangan/challenge.item.wnb-1-06.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-1-06. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text sunrise viewed from Sikunir above a sea of clouds. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-1-07 — Mi Ongklok

File: assets/tantangan/challenge.item.wnb-1-07.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-1-07. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a bowl of mi ongklok with beef satay, seen from above. Use a verified licensed photograph wherever possible. If illustrating, attach a verified photo and faithfully preserve real architecture, costume, anatomy and proportions. Never invent historical detail. Compose distinctive features across the whole square for puzzle tiles.

COMPOSITION AND DELIVERY
Target production canvas: 1200 × 1200 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a01 — Bundengan

File: assets/tantangan/challenge.item.wnb-4-a01.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a01. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a bundengan instrument made from a curved woven bamboo hood with strings. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a02 — Buah carica

File: assets/tantangan/challenge.item.wnb-4-a02.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a02. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text several small yellow carica fruits. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a03 — Keranjang ongklok

File: assets/tantangan/challenge.item.wnb-4-a03.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a small handled bamboo ongklok straining basket. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a04 — Daun teh

File: assets/tantangan/challenge.item.wnb-4-a04.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a04. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text fresh tea shoots and leaves. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a05 — Pepaya biasa

File: assets/tantangan/challenge.item.wnb-4-a05.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a05. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text one large ordinary papaya fruit. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a06 — Rigen

File: assets/tantangan/challenge.item.wnb-4-a06.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a06. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text an empty rectangular woven bamboo rigen tray. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a07 — Semangkuk mi ongklok

File: assets/tantangan/challenge.item.wnb-4-a07.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a07. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a bowl of mi ongklok. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a08 — Angklung

File: assets/tantangan/challenge.item.wnb-4-a08.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a08. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a bamboo angklung instrument. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a09 — Sasando

File: assets/tantangan/challenge.item.wnb-4-a09.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a09. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a sasando instrument. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a10 — Biji kopi

File: assets/tantangan/challenge.item.wnb-4-a10.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a10. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a small handful of coffee beans. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a11 — Kuluk Topeng Ireng

File: assets/tantangan/challenge.item.wnb-4-a11.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a11. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a Topeng Ireng feather kuluk headdress. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.item.wnb-4-a12 — Getuk

File: assets/tantangan/challenge.item.wnb-4-a12.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.item.wnb-4-a12. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text getuk cassava cakes. Make one isolated recognisable object with clear silhouette, identical lighting and quality for targets and decoys; no answer cues, labels or special glow.

COMPOSITION AND DELIVERY
Target production canvas: 240 × 240 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## challenge.wnb-4.scene — Pasar Oleh-oleh Dieng

File: assets/tantangan/challenge.wnb-4.scene.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as challenge.wnb-4.scene. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a lightly misty Dieng souvenir market, three rows of empty bamboo shelves or wooden tables, tea fields and temples in the distance. Keep all shelves empty: interactive objects will be placed by the application. Do not embed targets, decoys, text or buttons in the scene.

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.welcome — bg.welcome

File: assets/latar/bg.welcome.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.welcome. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground magical dawn panorama of the Kedu plain seen from a gentle hill, looking north: Mount Sindoro and Mount Sumbing as silhouettes on the left, Merbabu and Merapi on the right, terraced rice and tobacco fields and small village roofs with warm golden window lights, thin blue-grey mist in the valleys, a deep navy sky warming to soft gold at the horizon with a few fading stars, tiny floating golden light motes; the upper middle is open calm sky reserved for a logo; the centre bottom is calm for a start button

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.auth — bg.auth

File: assets/latar/bg.auth.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.auth. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground quiet interior of a Javanese pendopo reading pavilion at night, carved teak pillars, low bookshelves and rolled palm-leaf manuscripts in soft shadow, a single brass lantern glowing on a low table far to one side, very low contrast, soft focus, calm and safe atmosphere, large calm area in the centre

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.intro — bg.intro

File: assets/latar/bg.intro.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.intro. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground the keeper's old wooden joglo house on a hillside at night, warm lantern light glowing through the carved door and windows, the misty Kedu plain spreading below with scattered golden village lights, a starry navy sky, gentle cinematic mood; the left third and the lower third are calm and uncluttered

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.map — bg.map

File: assets/latar/bg.map.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.map. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground deep night sky high above the Kedu highlands, soft bands of cloud and blue-grey mist, faint constellations, mountain silhouettes only along the very bottom edge, strong soft vignette towards the edges, very calm and low contrast, centre intentionally plain because a framed map will cover it

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.reflection — bg.reflection

File: assets/latar/bg.reflection.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.reflection. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground warm golden-hour view of an open Javanese pendopo hall with carved teak pillars and woven pandan mats, the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light restored and shining brightly on a low table, beyond the pillars the clear Kedu plain with the five volcanoes and no mist at all, peaceful proud accomplished mood, calm centre

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.loading — bg.loading

File: assets/latar/bg.loading.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.loading. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground indigo night filled with slowly swirling the Mist of Forgetting: cold desaturated blue-grey mist (#8C97AA to #5B6478) drifting in soft layered bands, faint abstract wisps that dissolve like fading ink strokes and never form readable letters, eerie but never scary in mid-tone blue-grey, a soft circular clearing of calm, detail-free space in the centre, a few Shards of Light: small faceted crystal shards of warm golden light (#F0DFB8 core, #DFC087 edges) with a gentle glow and tiny sparkles glinting at the edges of the clearing, gentle vignette, minimal detail, suspenseful but gentle, overall mid-tone rather than dark because the image is shown at 45% opacity

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-01 — Dataran yang Bercahaya

File: assets/latar/bg.cerita-intro-01.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-01. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground night panorama of the Kedu plain ringed by Mount Sindoro, Sumbing, Merapi, Merbabu and the Menoreh hills, every village glowing with a gentle golden light called the Light of Kedu, fireflies of light rising softly, wonder

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-02 — Cahaya dari Ilmu dan Budaya

File: assets/latar/bg.cerita-intro-02.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-02. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground inside a joglo pendopo at night the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light stands on a carved teak stand; ribbons of its golden light drift upward and gently form faint silhouettes of a grandmother telling tales, a Borobudur-style relief panel, farmers singing in terraced fields, and a child reading, warm and reverent

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-03 — Kabut Lupa

File: assets/latar/bg.cerita-intro-03.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground the same glowing valley as village lights fade one by one, the Mist of Forgetting: cold desaturated blue-grey mist (#8C97AA to #5B6478) drifting in soft layered bands, faint abstract wisps that dissolve like fading ink strokes and never form readable letters, eerie but never scary rising from the valley floor and swallowing the fields, a few loose blank pages and faded relief shapes dissolving into the mist, cold and hushed

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-04 — Malam Lentera Retak

File: assets/latar/bg.cerita-intro-04.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-04. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground close view of the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light on its stand, one glass pane cracking with a bright fracture line, the Mist of Forgetting: cold desaturated blue-grey mist (#8C97AA to #5B6478) drifting in soft layered bands, faint abstract wisps that dissolve like fading ink strokes and never form readable letters, eerie but never scary coiling around it, twelve Shards of Light: small faceted crystal shards of warm golden light (#F0DFB8 core, #DFC087 edges) with a gentle glow and tiny sparkles bursting upward into the night sky towards three distant lands, dramatic but not violent

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-05 — Penjaga yang Menua

File: assets/latar/bg.cerita-intro-05.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-05. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground dim interior of the keeper's joglo, the cracked lantern with a weak flickering flame on a low table in the right half, cool shadows, an empty calm left side where the keeper will stand, quiet and sad

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-06 — Jaka, Pembawa Lentera

File: assets/latar/bg.cerita-intro-06.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-06. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground the carved doorway of the joglo opening onto a misty dawn, a stone path leading down into the valley, hopeful golden rim light streaming in, calm left side for a standing boy

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-07 — Cara Mengumpulkan Serpihan

File: assets/latar/bg.cerita-intro-07.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-07. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground bird's-eye storybook view of three lands under patches of mist: twin volcanoes with tobacco terraces, a great stepped stupa temple on a green hill, and a high cloud-covered plateau with lakes; four tiny golden sparks hidden in each land, clear and inviting

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-08 — Tiga Kunci Cahaya

File: assets/latar/bg.cerita-intro-08.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-08. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground warm lantern-lit porch of the joglo, three softly glowing symbols floating in the light on the right side — a wooden signpost, a stone relief panel, and a bamboo kentongan drum — calm left side for the keeper

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-intro-09 — Perjalanan Dimulai

File: assets/latar/bg.cerita-intro-09.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-intro-09. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground sunrise over the Kedu plain seen from the top of a footpath, the path winding down into golden mist towards three distant regions, a small glow of lantern light leading the way, adventurous and bright

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-penutup-01 — Lentera Menyala Kembali

File: assets/latar/bg.cerita-penutup-01.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-penutup-01. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground hilltop at night, a small boy seen from behind as a silhouette lifting the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light high, twelve Shards of Light: small faceted crystal shards of warm golden light (#F0DFB8 core, #DFC087 edges) with a gentle glow and tiny sparkles joining into it, a wave of golden light pouring across the whole plain, triumphant

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-penutup-02 — Kabut Tersibak

File: assets/latar/bg.cerita-penutup-02.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-penutup-02. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground bright morning panorama as the last mist lifts: the twin volcanoes and tobacco terraces on the left, the great stupa temple in the centre, the cloud plateau and colourful lake on the right, clear blue-gold sky, relief and joy

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-penutup-03 — Mbah Kedu Pulih

File: assets/latar/bg.cerita-penutup-03.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-penutup-03. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground the keeper's porch at golden hour, the restored lantern shining brightly on its stand in the right half, flowers and green plants around, warm and healthy mood, calm left side

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-penutup-04 — Janji Jaka

File: assets/latar/bg.cerita-penutup-04.webp

Style review: Perlu tinjau

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-penutup-04. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground a quiet village schoolyard under a big banyan tree at golden hour, children's books neatly stacked on a bamboo bench, soft lantern light, calm and sincere, calm left side

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.cerita-penutup-05 — Penjaga Lentera

File: assets/latar/bg.cerita-penutup-05.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.cerita-penutup-05. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground dusk over the Kedu plain where many small lanterns glow in homes, a village school, and along the paths, light spreading from house to house, hopeful ending, calm left side

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.temanggung.region — pagi, "Di Antara Dua Gunung"

File: assets/latar/bg.temanggung.region.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.temanggung.region. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground early morning in Temanggung seen from the east: Mount Sindoro (the symmetrical cone, right) and Mount Sumbing (broader and taller, left) rising side by side above terraced tobacco and coffee fields, a small village with tiled roofs, a wooden signpost at a crossroads half hidden in thin the Mist of Forgetting: cold desaturated blue-grey mist (#8C97AA to #5B6478) drifting in soft layered bands, faint abstract wisps that dissolve like fading ink strokes and never form readable letters, eerie but never scary, a glint of the Progo river, soft gold sunrise

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.magelang.region — fajar berkabut tipis, "Tanah Candi Agung"

File: assets/latar/bg.magelang.region.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.magelang.region. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground the classic sunrise view from the Menoreh hills: Borobudur temple on its green hill rising out of morning mist above palm forest, Merapi (gently smoking) and Merbabu behind it, the ring of mountains around the plain, calm and majestic, no people on the temple

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.wonosobo.region — fajar dingin, "Negeri di Atas Awan"

File: assets/latar/bg.wonosobo.region.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.wonosobo.region. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground the Dieng plateau above a sea of clouds at cold dawn, the small Arjuna temple complex in the middle distance, the green-turquoise Telaga Warna lake, terraced potato fields on steep slopes, drifting the Mist of Forgetting: cold desaturated blue-grey mist (#8C97AA to #5B6478) drifting in soft layered bands, faint abstract wisps that dissolve like fading ink strokes and never form readable letters, eerie but never scary between the hills, Mount Sindoro far away, cool blue light with the first warm sun on the peaks

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## ui.logo-hero — Logo utama tanpa tagline

File: assets/logo/ui.logo-hero.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as ui.logo-hero. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text ornamental title decoration for a game logo, wide 8:3 banner, large empty space in the centre reserved for a wordmark, delicate antique-gold filigree inspired by Javanese batik kawung and lung-lungan vine motifs curling from both sides, a small glowing brass lantern at the top centre, soft golden light rays, thin wisps of blue-grey mist along the bottom edge, perfectly symmetrical, isolated on a plain flat #0B1320 background for extraction, no letters

COMPOSITION AND DELIVERY
Target production canvas: 1600 × 600 pixels; aspect ratio 8:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## ui.logo — Emblem panel tanpa tulisan

File: assets/logo/ui.logo.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as ui.logo. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text circular emblem for the GELITA game: the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light glowing at the centre inside an octagonal antique-gold frame, a ring of tiny kawung batik motifs around it, three small golden shards orbiting the lantern, deep navy enamel background inside the frame, bold simple shapes that stay readable at 36 pixels, symmetrical, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## ui.btn-start — Tombol MULAI

File: assets/antarmuka/ui.btn-start.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as ui.btn-start. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a single wide pill-shaped game button seen straight on, polished antique-gold surface with a soft bevel and a subtle kawung batik pattern engraved near both ends, warm inner glow, a thin darker gold rim, generous empty area in the middle for a label, perfectly symmetrical, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery Add the exact label MULAI manually after image generation using Plus Jakarta Sans ExtraBold; never ask image generation to spell the label.

COMPOSITION AND DELIVERY
Target production canvas: 720 × 240 pixels; aspect ratio 3:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## ui.btn-start.en — Tombol START

File: assets/antarmuka/ui.btn-start.en.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as ui.btn-start.en. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a single wide pill-shaped game button seen straight on, polished antique-gold surface with a soft bevel and a subtle kawung batik pattern engraved near both ends, warm inner glow, a thin darker gold rim, generous empty area in the middle for a label, perfectly symmetrical, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery Add the exact label START manually after image generation using Plus Jakarta Sans ExtraBold; never ask image generation to spell the label.

COMPOSITION AND DELIVERY
Target production canvas: 720 × 240 pixels; aspect ratio 3:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## ui.placeholder — Gambar pengganti

File: assets/antarmuka/ui.placeholder.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as ui.placeholder. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a clean raster concept for a 4:3 placeholder graphic. Thin dashed gold border, simple central lantern, and an empty area for the exact Indonesian label “Gambar belum tersedia”. Add that label later as editable text. Plain calm background, no external logos or decorative clutter. The final production asset will be redrawn as a lightweight SVG; the generated image itself is not SVG.

COMPOSITION AND DELIVERY
Target production canvas: 400 × 300 pixels; aspect ratio 4:3. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## app.icon.svg — Ikon aplikasi icon.svg

File: assets/ikon/app.icon.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as app.icon.svg. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light Front view, bold simplified shape, navy background, lantern within central 70 percent circle. Redraw as vector before exporting.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## app.icon-512.png — Ikon aplikasi icon-512.png

File: assets/ikon/app.icon-512.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as app.icon-512.png. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light Front view, bold simplified shape, navy background, lantern within central 70 percent circle. Redraw as vector before exporting.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## app.icon-192.png — Ikon aplikasi icon-192.png

File: assets/ikon/app.icon-192.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as app.icon-192.png. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light Front view, bold simplified shape, navy background, lantern within central 70 percent circle. Redraw as vector before exporting.

COMPOSITION AND DELIVERY
Target production canvas: 192 × 192 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## app.icon-maskable-512.png — Ikon aplikasi icon-maskable-512.png

File: assets/ikon/app.icon-maskable-512.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as app.icon-maskable-512.png. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light Front view, bold simplified shape, navy background, lantern within central 70 percent circle. Redraw as vector before exporting.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## app.apple-touch-icon.png — Ikon aplikasi apple-touch-icon.png

File: assets/ikon/app.apple-touch-icon.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as app.apple-touch-icon.png. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light Front view, bold simplified shape, navy background, lantern within central 70 percent circle. Redraw as vector before exporting.

COMPOSITION AND DELIVERY
Target production canvas: 180 × 180 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## app.favicon.ico — Ikon aplikasi favicon.ico

File: assets/ikon/app.favicon.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as app.favicon.ico. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light Front view, bold simplified shape, navy background, lantern within central 70 percent circle. Redraw as vector before exporting.

COMPOSITION AND DELIVERY
Target production canvas: 32 × 32 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.kedu — Peta utama Kedu

File: assets/peta/map.kedu.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.kedu. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text illustrated storybook map of the Kedu region of Central Java seen from above at a slight angle, painted on dark indigo parchment with antique-gold ink linework and soft watercolour terrain, north at the top; the Dieng plateau with a tiny turquoise lake and tiny temples in the upper left, the twin volcanoes Sindoro (north) and Sumbing (south) in the upper centre, terraced tobacco and coffee fields to their east, Merbabu and a gently smoking Merapi on the right edge, a small green Tidar hill, the great stupa temple Borobudur in the lower centre, the Menoreh hills along the lower left, a thin blue Progo river winding from the volcano slopes down to the bottom edge, tiny glowing village dots, soft the Mist of Forgetting: cold desaturated blue-grey mist (#8C97AA to #5B6478) drifting in soft layered bands, faint abstract wisps that dissolve like fading ink strokes and never form readable letters, eerie but never scary only in the top-left corner and along the right edge, three calm open areas of plain terrain around the region markers, an ornamental compass rose without letters in the lower right corner

COMPOSITION AND DELIVERY
Target production canvas: 1400 × 900 pixels; aspect ratio 14:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.region.temanggung — Peta wilayah Temanggung

File: assets/peta/map.region.temanggung.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.region.temanggung. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Illustrated regional map of temanggung, featuring Sindoro and Sumbing, tobacco and coffee terraces. A path links four calm stops for image puzzle, fill-the-gap, true-or-false reading, and hidden-object activities. No built-in numbers, labels, pins or buttons. Reserve clear space around stops; final coordinates must be supplied from the current configuration.

COMPOSITION AND DELIVERY
Target production canvas: 1400 × 900 pixels; aspect ratio 14:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.region.magelang — Peta wilayah Magelang

File: assets/peta/map.region.magelang.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.region.magelang. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Illustrated regional map of magelang, featuring Borobudur, Menoreh hills, Merapi and Merbabu. A path links four calm stops for image puzzle, fill-the-gap, true-or-false reading, and hidden-object activities. No built-in numbers, labels, pins or buttons. Reserve clear space around stops; final coordinates must be supplied from the current configuration.

COMPOSITION AND DELIVERY
Target production canvas: 1400 × 900 pixels; aspect ratio 14:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.region.wonosobo — Peta wilayah Wonosobo

File: assets/peta/map.region.wonosobo.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.region.wonosobo. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Illustrated regional map of wonosobo, featuring Dieng plateau, lakes, tea fields and distant Sindoro. A path links four calm stops for image puzzle, fill-the-gap, true-or-false reading, and hidden-object activities. No built-in numbers, labels, pins or buttons. Reserve clear space around stops; final coordinates must be supplied from the current configuration.

COMPOSITION AND DELIVERY
Target production canvas: 1400 × 900 pixels; aspect ratio 14:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## reward.badge.temanggung — Lencana Temanggung

File: assets/lencana/reward.badge.temanggung.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reward.badge.temanggung. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round gold-rim navy enamel achievement medal. Emblem visual brief: two twin mountain peaks with one tobacco leaf in front. One large readable emblem, 312 px diameter, no text.

COMPOSITION AND DELIVERY
Target production canvas: 320 × 320 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## reward.badge.magelang — Lencana Magelang

File: assets/lencana/reward.badge.magelang.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reward.badge.magelang. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round gold-rim navy enamel achievement medal. Emblem visual brief: a Borobudur stupa silhouette with three rows of smaller stupas. One large readable emblem, 312 px diameter, no text.

COMPOSITION AND DELIVERY
Target production canvas: 320 × 320 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## reward.badge.wonosobo — Lencana Wonosobo

File: assets/lencana/reward.badge.wonosobo.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as reward.badge.wonosobo. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round gold-rim navy enamel achievement medal. Emblem visual brief: a small Arjuna temple gateway above a cloud, with a turquoise lake-water droplet. One large readable emblem, 312 px diameter, no text.

COMPOSITION AND DELIVERY
Target production canvas: 320 × 320 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.idle.1 — Jaka · idle · frame 1

File: assets/karakter/char.jaka.idle.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.idle.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, relaxed neutral stance, arms loose, curious friendly half-smile, looking slightly ahead. Frame 1 of 3. Motion direction: base neutral pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.idle.2 — Jaka · idle · frame 2

File: assets/karakter/char.jaka.idle.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.idle.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, relaxed neutral stance, arms loose, curious friendly half-smile, looking slightly ahead. Frame 2 of 3. Motion direction: gentle inhale: shoulders and chest rise 2 px; lantern swings 2 degrees to the right. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.idle.3 — Jaka · idle · frame 3

File: assets/karakter/char.jaka.idle.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.idle.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, relaxed neutral stance, arms loose, curious friendly half-smile, looking slightly ahead. Frame 3 of 3. Motion direction: gentle exhale: torso lowers 1 px; lantern swings 2 degrees to the left. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.happy.1 — Jaka · happy · frame 1

File: assets/karakter/char.jaka.happy.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.happy.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, joyful, big open grin, eyes bright. Frame 1 of 3. Motion direction: broad smile, lantern slightly raised. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.happy.2 — Jaka · happy · frame 2

File: assets/karakter/char.jaka.happy.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.happy.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, joyful, big open grin, eyes bright. Frame 2 of 3. Motion direction: a small hop, feet lifted 8 px. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.happy.3 — Jaka · happy · frame 3

File: assets/karakter/char.jaka.happy.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.happy.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, joyful, big open grin, eyes bright. Frame 3 of 3. Motion direction: left fist raised joyfully, eyes curved into a smile; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.bow.1 — Jaka · bow · frame 1

File: assets/karakter/char.jaka.bow.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.bow.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, respectful Javanese bow with hands clasped in front at the waist (ngapurancang), lantern held with both hands in front, calm sincere smile. Frame 1 of 3. Motion direction: upright, hands clasped in front. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.bow.2 — Jaka · bow · frame 2

File: assets/karakter/char.jaka.bow.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.bow.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, respectful Javanese bow with hands clasped in front at the waist (ngapurancang), lantern held with both hands in front, calm sincere smile. Frame 2 of 3. Motion direction: bow forward approximately 15 degrees. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.bow.3 — Jaka · bow · frame 3

File: assets/karakter/char.jaka.bow.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.bow.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, respectful Javanese bow with hands clasped in front at the waist (ngapurancang), lantern held with both hands in front, calm sincere smile. Frame 3 of 3. Motion direction: bow forward approximately 30 degrees with lowered head; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.sad.1 — Jaka · sad · frame 1

File: assets/karakter/char.jaka.sad.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.sad.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, sad and sorry, shoulders dropped, eyebrows raised inward, small frown, lantern hanging low. Frame 1 of 3. Motion direction: shoulders lowered. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.sad.2 — Jaka · sad · frame 2

File: assets/karakter/char.jaka.sad.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.sad.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, sad and sorry, shoulders dropped, eyebrows raised inward, small frown, lantern hanging low. Frame 2 of 3. Motion direction: head bowed. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.sad.3 — Jaka · sad · frame 3

File: assets/karakter/char.jaka.sad.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.sad.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, sad and sorry, shoulders dropped, eyebrows raised inward, small frown, lantern hanging low. Frame 3 of 3. Motion direction: look down while fingers twist the bag strap; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.afraid.1 — Jaka · afraid · frame 1

File: assets/karakter/char.jaka.afraid.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.afraid.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, startled and anxious (not terrified), wide eyes, raised eyebrows, leaning slightly back, lantern pulled close to chest. Frame 1 of 3. Motion direction: startled, body leaning back. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.afraid.2 — Jaka · afraid · frame 2

File: assets/karakter/char.jaka.afraid.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.afraid.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, startled and anxious (not terrified), wide eyes, raised eyebrows, leaning slightly back, lantern pulled close to chest. Frame 2 of 3. Motion direction: both hands close to the chest. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.afraid.3 — Jaka · afraid · frame 3

File: assets/karakter/char.jaka.afraid.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.afraid.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, startled and anxious (not terrified), wide eyes, raised eyebrows, leaning slightly back, lantern pulled close to chest. Frame 3 of 3. Motion direction: slight crouch and trembling shoulders; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.determined.1 — Jaka · determined · frame 1

File: assets/karakter/char.jaka.determined.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.determined.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, confident and brave, chin up, firm smile, one foot forward, lantern lifted to chest height. Frame 1 of 3. Motion direction: chin raised. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.determined.2 — Jaka · determined · frame 2

File: assets/karakter/char.jaka.determined.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.determined.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, confident and brave, chin up, firm smile, one foot forward, lantern lifted to chest height. Frame 2 of 3. Motion direction: left fist in front of the chest. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.jaka.determined.3 — Jaka · determined · frame 3

File: assets/karakter/char.jaka.determined.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.jaka.determined.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, confident and brave, chin up, firm smile, one foot forward, lantern lifted to chest height. Frame 3 of 3. Motion direction: firm stance with one foot forward, lantern at chest height; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.idle.1 — Mbah Kedu · idle · frame 1

File: assets/karakter/char.kedu.idle.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.idle.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, calm wise stance, both hands resting on top of the walking stick, gentle expression. Frame 1 of 3. Motion direction: base neutral pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.idle.2 — Mbah Kedu · idle · frame 2

File: assets/karakter/char.kedu.idle.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.idle.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, calm wise stance, both hands resting on top of the walking stick, gentle expression. Frame 2 of 3. Motion direction: subtle inhale. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.idle.3 — Mbah Kedu · idle · frame 3

File: assets/karakter/char.kedu.idle.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.idle.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, calm wise stance, both hands resting on top of the walking stick, gentle expression. Frame 3 of 3. Motion direction: small nod, head lowered 3 px. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.smile.1 — Mbah Kedu · smile · frame 1

File: assets/karakter/char.kedu.smile.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.smile.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, warm kind smile, eyes crinkled, free hand raised with the palm up in a gentle explaining gesture. Frame 1 of 3. Motion direction: gentle smile. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.smile.2 — Mbah Kedu · smile · frame 2

File: assets/karakter/char.kedu.smile.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.smile.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, warm kind smile, eyes crinkled, free hand raised with the palm up in a gentle explaining gesture. Frame 2 of 3. Motion direction: eyes narrowing warmly in a smile. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.smile.3 — Mbah Kedu · smile · frame 3

File: assets/karakter/char.kedu.smile.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.smile.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, warm kind smile, eyes crinkled, free hand raised with the palm up in a gentle explaining gesture. Frame 3 of 3. Motion direction: left hand raised, palm upward; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.worried.1 — Mbah Kedu · worried · frame 1

File: assets/karakter/char.kedu.worried.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.worried.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, worried and concerned, brows knit, looking into the distance, slightly hunched. Frame 1 of 3. Motion direction: brows knitted. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.worried.2 — Mbah Kedu · worried · frame 2

File: assets/karakter/char.kedu.worried.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.worried.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, worried and concerned, brows knit, looking into the distance, slightly hunched. Frame 2 of 3. Motion direction: one hand stroking the beard. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.worried.3 — Mbah Kedu · worried · frame 3

File: assets/karakter/char.kedu.worried.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.worried.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, worried and concerned, brows knit, looking into the distance, slightly hunched. Frame 3 of 3. Motion direction: look into the distance with shoulders slightly hunched; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.weak.1 — Mbah Kedu · weak · frame 1

File: assets/karakter/char.kedu.weak.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.weak.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, exhausted and weakened, leaning heavily on the walking stick, other hand on his chest, knees slightly bent, pale cooler skin tone, half-closed eyes. Frame 1 of 3. Motion direction: lean on the walking stick. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.weak.2 — Mbah Kedu · weak · frame 2

File: assets/karakter/char.kedu.weak.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.weak.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, exhausted and weakened, leaning heavily on the walking stick, other hand on his chest, knees slightly bent, pale cooler skin tone, half-closed eyes. Frame 2 of 3. Motion direction: knees slightly bent. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## char.kedu.weak.3 — Mbah Kedu · weak · frame 3

File: assets/karakter/char.kedu.weak.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as char.kedu.weak.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow, exhausted and weakened, leaning heavily on the walking stick, other hand on his chest, knees slightly bent, pale cooler skin tone, half-closed eyes. Frame 3 of 3. Motion direction: slump a little more with half-closed eyes; hold this pose. Preserve identity, outfit, body scale and foot anchor at y=876; body axis x=350. Transparent alpha.

COMPOSITION AND DELIVERY
Target production canvas: 700 × 900 pixels; aspect ratio 7:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## ui.pin — ui.pin

File: assets/ikon/ui.pin.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as ui.pin. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text round antique-gold map-pin medallion with a small navy lantern glyph in the centre, thick rim, bold and simple, readable at 56 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## ui.lantern — ui.lantern

File: assets/ikon/ui.lantern.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as ui.lantern. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light front view as a simplified icon, bold outlines, bright flame, readable at 28 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.pin.temanggung — map.pin.temanggung

File: assets/ikon/map.pin.temanggung.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.pin.temanggung. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text round gold map-pin medallion with twin volcano peaks and a small tobacco leaf, navy enamel, readable at 56 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.pin.magelang — map.pin.magelang

File: assets/ikon/map.pin.magelang.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.pin.magelang. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text round gold map-pin medallion with a bell-shaped stupa silhouette, navy enamel, readable at 56 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.pin.wonosobo — map.pin.wonosobo

File: assets/ikon/map.pin.wonosobo.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.pin.wonosobo. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text round gold map-pin medallion with a small temple above a puff of cloud, navy enamel, readable at 56 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.lantern.temanggung — map.lantern.temanggung

File: assets/ikon/map.lantern.temanggung.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.lantern.temanggung. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light as a bold icon with a soft green-gold flame, readable at 30 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.lantern.magelang — map.lantern.magelang

File: assets/ikon/map.lantern.magelang.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.lantern.magelang. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light as a bold icon with a warm stone-gold flame, readable at 30 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## map.lantern.wonosobo — map.lantern.wonosobo

File: assets/ikon/map.lantern.wonosobo.webp

Style review: Sesuai gaya

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as map.lantern.wonosobo. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Lentera Kedu: an antique hexagonal brass hand lantern about 30 cm tall with six clear glass panes, a pierced brass cap with a kawung pattern, a ring handle on top, and a warm golden flame inside casting soft light as a bold icon with a cool turquoise-gold flame, readable at 30 px, single isolated subject, centred, whole subject visible with even margins, transparent alpha background, no cast shadow, no ground, no scenery

COMPOSITION AND DELIVERY
Target production canvas: 256 × 256 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.loading.temanggung — bg.loading.temanggung

File: assets/latar/bg.loading.temanggung.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.loading.temanggung. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground a footpath climbing between tobacco terraces towards the twin volcanoes at dawn, calm centre for a title

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.loading.magelang — bg.loading.magelang

File: assets/latar/bg.loading.magelang.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.loading.magelang. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground a path through palm trees towards the silhouette of Borobudur in morning mist, calm centre

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## bg.loading.wonosobo — bg.loading.wonosobo

File: assets/latar/bg.loading.wonosobo.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as bg.loading.wonosobo. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text wide 16:9 cinematic landscape composition, main subject inside the central 75% of the width and the central 80% of the height, horizon between 55% and 65% of the height, lower third calm and slightly darker for text panels, top 8% free of important detail, mid-tone exposure that stays readable under a dark navy overlay of 35% at the top to 75% at the bottom, no people in the foreground a winding mountain road rising into a sea of clouds towards the Dieng plateau, calm centre

COMPOSITION AND DELIVERY
Target production canvas: 1920 × 1080 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency. The final background must be exactly 16:9. Keep interface text, labels and controls out of the image.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.1 — Avatar Lentera Kedu

File: assets/ikon/avatar.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: the Lantern of Kedu. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.2 — Avatar Serpihan Cahaya

File: assets/ikon/avatar.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.2. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: a Shard of Light. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.3 — Avatar gunung kembar Sindoro–Sumbing

File: assets/ikon/avatar.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.3. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: the twin peaks of Sindoro and Sumbing. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.4 — Avatar stupa Borobudur

File: assets/ikon/avatar.4.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.4. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: a Borobudur stupa. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.5 — Avatar kuda lumping

File: assets/ikon/avatar.5.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.5. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: a woven bamboo kuda lumping hobby horse. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.6 — Avatar kuluk Topeng Ireng

File: assets/ikon/avatar.6.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.6. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: a Topeng Ireng feather kuluk headdress. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.7 — Avatar buah carica

File: assets/ikon/avatar.7.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.7. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: a carica fruit. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.8 — Avatar Telaga Warna

File: assets/ikon/avatar.8.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.8. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: the Telaga Warna lake. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.9 — Avatar kendang

File: assets/ikon/avatar.9.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.9. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: a Javanese kendang drum. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## avatar.10 — Avatar bundengan

File: assets/ikon/avatar.10.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as avatar.10. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Round avatar medallion with thick navy rim, parchment centre and one large gold emblem. Motif: a bundengan bamboo-hood string instrument. No human face, no text. Readable at 48 px.

COMPOSITION AND DELIVERY
Target production canvas: 512 × 512 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use true transparency outside the subject; preserve alpha and do not draw a checkerboard.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, user interface, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## icon.home — home — beranda / Peta Kedu

File: assets/ikon/icon.home.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.home. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: gabled roof above a house body with a central doorway. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.left — left — kembali / lanjut

File: assets/ikon/icon.left.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.left. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: single left-pointing chevron. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.right — right — kembali / lanjut

File: assets/ikon/icon.right.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.right. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: single right-pointing chevron. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.up — up — naik / turun

File: assets/ikon/icon.up.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.up. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: single upward chevron. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.down — down — naik / turun

File: assets/ikon/icon.down.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.down. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: single downward chevron. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.sound — sound — suara menyala

File: assets/ikon/icon.sound.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.sound. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: speaker with two sound-wave curves. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.sound-off — sound-off — suara mati

File: assets/ikon/icon.sound-off.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.sound-off. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: speaker with a crossing mute mark. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.logout — logout — keluar

File: assets/ikon/icon.logout.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.logout. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: door frame with an arrow exiting to the right. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.lock — lock — terkunci

File: assets/ikon/icon.lock.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.lock. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: padlock with an arched shackle. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.check — check — benar / selesai

File: assets/ikon/icon.check.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.check. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: check mark. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.cross — cross — salah / tutup

File: assets/ikon/icon.cross.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.cross. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: X-shaped close mark. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.star — star — bintang / tuntas

File: assets/ikon/icon.star.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.star. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: five-pointed star; the interface may fill it when earned. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.book — book — Pustaka

File: assets/ikon/icon.book.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.book. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: book with a page-divider line. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.map — map — peta

File: assets/ikon/icon.map.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.map. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: three-panel folded map. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.play — play — putar

File: assets/ikon/icon.play.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.play. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: filled triangular play symbol. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.pause — pause — jeda

File: assets/ikon/icon.pause.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.pause. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: two vertical bars. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.replay — replay — ulangi

File: assets/ikon/icon.replay.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.replay. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: counterclockwise circular arrow. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.text — text — transkrip

File: assets/ikon/icon.text.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.text. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: three horizontal lines, with the last shorter. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.hint — hint — petunjuk

File: assets/ikon/icon.hint.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.hint. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: light bulb. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.clock — clock — waktu

File: assets/ikon/icon.clock.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.clock. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: clock face with two hands. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.building — building — sumber resmi / sekolah

File: assets/ikon/icon.building.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.building. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: roofed building with a doorway. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.question — question — tidak jelas / anonim

File: assets/ikon/icon.question.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.question. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: circle enclosing a question mark. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.user — user — profil

File: assets/ikon/icon.user.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.user. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: head and shoulders. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.users — users — peserta

File: assets/ikon/icon.users.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.users. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: two human silhouettes. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.lantern — lantern — lentera / serpihan

File: assets/ikon/icon.lantern.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.lantern. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: hanging hook, trapezoidal lantern body, base and a simple flame line. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.download — download — unduh / pasang aplikasi

File: assets/ikon/icon.download.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.download. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: downward arrow entering a tray. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.upload — upload — unggah

File: assets/ikon/icon.upload.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.upload. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: upward arrow leaving a tray. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.eye — eye — lihat sandi

File: assets/ikon/icon.eye.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.eye. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: eye outline with a pupil. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.menu — menu — menu

File: assets/ikon/icon.menu.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.menu. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: three horizontal menu lines. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.search — search — cari

File: assets/ikon/icon.search.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.search. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: magnifying glass. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.info — info — informasi

File: assets/ikon/icon.info.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.info. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: circle enclosing a lowercase i. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.warn — warn — peringatan

File: assets/ikon/icon.warn.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.warn. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: triangle enclosing an exclamation mark. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.grid — grid — kisi

File: assets/ikon/icon.grid.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.grid. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: four small squares. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.chart — chart — grafik

File: assets/ikon/icon.chart.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.chart. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: bar chart. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.list — list — daftar

File: assets/ikon/icon.list.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.list. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: bulleted list. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.target — target — ketepatan

File: assets/ikon/icon.target.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.target. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: three concentric circles. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.trend — trend — tren

File: assets/ikon/icon.trend.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.trend. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: rising line ending in an arrow. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.message — message — masukan / narasi

File: assets/ikon/icon.message.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.message. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: speech bubble. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.image — image — gambar

File: assets/ikon/icon.image.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.image. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: picture frame containing a sun and a mountain. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.flask — flask — penelitian

File: assets/ikon/icon.flask.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.flask. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: laboratory flask. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.shield — shield — keamanan

File: assets/ikon/icon.shield.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.shield. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: shield outline. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.key — key — kata sandi

File: assets/ikon/icon.key.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.key. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: key silhouette. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.edit — edit — sunting

File: assets/ikon/icon.edit.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.edit. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: pencil. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.trash — trash — hapus

File: assets/ikon/icon.trash.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.trash. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: trash bin. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.puzzle — puzzle — puzzle

File: assets/ikon/icon.puzzle.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.puzzle. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: single jigsaw puzzle piece. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.sparkle — sparkle — istimewa

File: assets/ikon/icon.sparkle.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.sparkle. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: eight radial sparkle rays. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.link — link — tautan

File: assets/ikon/icon.link.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.link. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: two linked chain segments. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.video — video — video

File: assets/ikon/icon.video.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.video. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create one clean raster concept for a production SVG interface icon. Symbol: video camera. Use a 24 by 24 logical grid, a consistent 2-unit line weight, rounded caps and joins, and 2-unit optical margins. One solid colour, no shading, bevel, texture or decorative frame. Use a filled triangle for play and 3-unit strokes for pause. Show only the icon on a transparent background. Render at a larger working resolution so edges are clear. This is an image concept to be traced into SVG; do not output code or claim the raster image is a vector file.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 24 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.footsteps — footsteps

File: assets/ikon/icon.footsteps.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.footsteps. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a clean raster concept to be redrawn as SVG. Filled elongated sole with five rounded toes decreasing in size, currentColor. Mirror the opposite foot in CSS.

COMPOSITION AND DELIVERY
Target production canvas: 24 × 40 pixels; aspect ratio 3:5. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## icon.rotate-gate — rotate-gate

File: assets/ikon/icon.rotate-gate.svg

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as icon.rotate-gate. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
Create a clean raster concept to be redrawn as SVG. Portrait phone rectangle 36 by 64 with corner radius 7 and a curved arrow inviting rotation to landscape. Stroke 4, round caps.

COMPOSITION AND DELIVERY
Target production canvas: 120 × 120 pixels; aspect ratio 1:1. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Generate a raster design reference at a sufficiently clear working resolution. SVG paths, favicon sizes and final small pixel dimensions are post-production tasks, not properties guaranteed by this image prompt. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
Keep the design clean, faithful to the brief, free of watermarks and free of unintended lettering.

Negative: See prompt constraints.

---

## library.temanggung.p1.1 — Selamat Datang di Temanggung

File: assets/pustaka/library.temanggung.p1.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Taman_Wisata_Alam_Posong,_Temanggung.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p1.2 — Kabut_Tipis_Temanggung.jpg

File: assets/pustaka/library.temanggung.p1.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Kabut_Tipis_Temanggung.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p2.1 — Si Kembar Sindoro dan Sumbing

File: assets/pustaka/library.temanggung.p2.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Sindoro_sumbing.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p2.2 — Gunung_Sindoro_dari_puncak_Gunung_Sumbing.jpg

File: assets/pustaka/library.temanggung.p2.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Gunung_Sindoro_dari_puncak_Gunung_Sumbing.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p2.3 — Gunung_Sumbing_Temanggung.jpg

File: assets/pustaka/library.temanggung.p2.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Gunung_Sumbing_Temanggung.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p3.1 — Asal-usul Nama dan Sejarah Temanggung

File: assets/pustaka/library.temanggung.p3.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Lambang_Kabupaten_Temanggung.png. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p4.1 — Tembakau Srintil dan Kopi Temanggung

File: assets/pustaka/library.temanggung.p4.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Perkebunan_Tembakau_di_Lereng_Gunung_Sindoro.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p4.2 — Petani_Tembakau_memeriksa_daun_Tembakau_yang_akan_dipanen.jpg

File: assets/pustaka/library.temanggung.p4.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Petani_Tembakau_memeriksa_daun_Tembakau_yang_akan_dipanen.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p4.3 — Tobacco_Fields_on_the_slopes_of_Mt._Sumbing.jpg

File: assets/pustaka/library.temanggung.p4.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Tobacco_Fields_on_the_slopes_of_Mt._Sumbing.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p5.1 — Jejak Mataram Kuno

File: assets/pustaka/library.temanggung.p5.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Situs_liyangan.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p5.2 — Candi_Pringapus_Temanggung_Jateng.jpg

File: assets/pustaka/library.temanggung.p5.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Candi_Pringapus_Temanggung_Jateng.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p5.3 — Arca_Nandi_dalam_bilik_Candi_Pringapus,_Mei_2022.jpg

File: assets/pustaka/library.temanggung.p5.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Arca_Nandi_dalam_bilik_Candi_Pringapus,_Mei_2022.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p6.1 — Umbul Jumprit, Hulu Kali Progo

File: assets/pustaka/library.temanggung.p6.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Segoro_Wedi_Gunung_Sindoro_dengan_latar_Gunung_Sumbing.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p8.1 — Kuda Lumping dan Tradisi Temanggung

File: assets/pustaka/library.temanggung.p8.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Kuda_lumping_Temanggung.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p8.2 — youtube.com/watch?v=IXDk03NgHqQ

File: assets/pustaka/library.temanggung.p8.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named youtube.com/watch?v=IXDk03NgHqQ. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p1.1 — Selamat Datang di Magelang

File: assets/pustaka/library.magelang.p1.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Pemandangan_Gunung_Andong_Magelang.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p1.2 — Lambang_Kabupaten_Magelang.jpg

File: assets/pustaka/library.magelang.p1.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Lambang_Kabupaten_Magelang.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p2.1 — Candi Borobudur, Mahakarya Dunia

File: assets/pustaka/library.magelang.p2.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Borobudur_temple_from_above.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p2.2 — Borobudur_stupas_on_upper_terrace.jpg

File: assets/pustaka/library.magelang.p2.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Borobudur_stupas_on_upper_terrace.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p2.3 — youtube.com/watch?v=txujqGtB_6g

File: assets/pustaka/library.magelang.p2.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named youtube.com/watch?v=txujqGtB_6g. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p3.1 — Tiga Alam di Borobudur

File: assets/pustaka/library.magelang.p3.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Borobudur_-_Karmawibhangga_-_013_Karmavibhanga_Section_Uncovered_(11831905453).jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p3.2 — Relief_Di_Candi_Borobudur.jpg

File: assets/pustaka/library.magelang.p3.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Relief_Di_Candi_Borobudur.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p3.3 — Stupa_Borobudur.jpg

File: assets/pustaka/library.magelang.p3.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Stupa_Borobudur.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p4.1 — Menemukan dan Memugar Borobudur

File: assets/pustaka/library.magelang.p4.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Borobudur-Temple-Park_Indonesia_Stupas-of-Borobudur-01.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p5.1 — Mendut, Pawon, dan Perjalanan Waisak

File: assets/pustaka/library.magelang.p5.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Mendut_Temple.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p5.2 — Buddha's_statue_inside_candi_Mendut.JPG

File: assets/pustaka/library.magelang.p5.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Buddha's_statue_inside_candi_Mendut.JPG. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p5.3 — Candi_Pawon_6.jpg

File: assets/pustaka/library.magelang.p5.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Candi_Pawon_6.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p6.1 — Topeng Ireng, Tarian Penuh Semangat

File: assets/pustaka/library.magelang.p6.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Penari_Topeng_Ireng_03.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p6.2 — Topeng_Ireng_(4).jpg

File: assets/pustaka/library.magelang.p6.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Topeng_Ireng_(4).jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p6.3 — youtube.com/watch?v=CicQwPmwCWQ

File: assets/pustaka/library.magelang.p6.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named youtube.com/watch?v=CicQwPmwCWQ. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p7.1 — Gunung Tidar, Paku Tanah Jawa

File: assets/pustaka/library.magelang.p7.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Makam_Syekh_Subakir.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.magelang.p9.1 — Rasa dan Karya Magelang

File: assets/pustaka/library.magelang.p9.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Getuk_Magelang.JPG. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p1.1 — Selamat Datang di Wonosobo

File: assets/pustaka/library.wonosobo.p1.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Malam_di_Wonosobo.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p1.2 — Lambang_Kabupaten_Wonosobo.webp

File: assets/pustaka/library.wonosobo.p1.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Lambang_Kabupaten_Wonosobo.webp. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p2.1 — Dieng, Tempat Para Dewa

File: assets/pustaka/library.wonosobo.p2.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Dieng_Plateau_view_from_complex_of_Candi_Arjuna.JPG. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p2.2 — Peta_Kawasan_Dataran_Tinggi_Dieng.jpg

File: assets/pustaka/library.wonosobo.p2.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Peta_Kawasan_Dataran_Tinggi_Dieng.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p3.1 — Telaga Warna dan Telaga Pengilon

File: assets/pustaka/library.wonosobo.p3.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Telaga_Warna_Dieng_Jawa_Tengah.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p3.2 — Telaga_Warna_in_The_Dieng_Plateau.jpg

File: assets/pustaka/library.wonosobo.p3.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Telaga_Warna_in_The_Dieng_Plateau.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p3.3 — Telaga_Warna_Dieng_02.jpg

File: assets/pustaka/library.wonosobo.p3.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Telaga_Warna_Dieng_02.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p4.1 — Sembungan dan Sikunir

File: assets/pustaka/library.wonosobo.p4.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Sunrise_di_Bukit_Sikunir.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p4.2 — The_Golden_Sunrise_Sikunir.jpg

File: assets/pustaka/library.wonosobo.p4.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named The_Golden_Sunrise_Sikunir.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p6.1 — Candi-candi Dieng

File: assets/pustaka/library.wonosobo.p6.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Kompleks_Candi_Arjuna_-_Dieng_Plateau.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p6.2 — Pagi_Candi_Arjuna_Dieng.jpg

File: assets/pustaka/library.wonosobo.p6.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Pagi_Candi_Arjuna_Dieng.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p7.1 — Tari Topeng Lengger dan Bundengan

File: assets/pustaka/library.wonosobo.p7.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named youtube.com/watch?v=id_j81YL5QI. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p8.1 — Tradisi Rambut Gimbal Dieng

File: assets/pustaka/library.wonosobo.p8.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named youtube.com/watch?v=om5yK2B3DII. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p9.1 — Rasa Wonosobo

File: assets/pustaka/library.wonosobo.p9.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Mi_ongklok_sate_sapi_Wonosobo.JPG. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p9.2 — Mountain_papaya_(Vasconcellea_pubescens).jpg

File: assets/pustaka/library.wonosobo.p9.2.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Mountain_papaya_(Vasconcellea_pubescens).jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.wonosobo.p9.3 — Es_carica_dieng_wonosobo.jpg

File: assets/pustaka/library.wonosobo.p9.3.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

SOURCE ACQUISITION BRIEF: Locate the exact licensed reference named Es_carica_dieng_wonosobo.jpg. Verify creator, licence, attribution and factual relevance before use. Preserve documentary content; do not synthesize a substitute and present it as a real photograph. For video use the official link or an authorised original recording; do not assume a downloadable source.

Negative: See prompt constraints.

---

## library.temanggung.p8.2.poster — library.temanggung.p8.2.poster

File: assets/pustaka/library.temanggung.p8.2.poster.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.temanggung.p8.2.poster. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text craftspeople in Temanggung painting woven-bamboo hobby horses for the jaran kepang dance

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.magelang.p2.3.poster — library.magelang.p2.3.poster

File: assets/pustaka/library.magelang.p2.3.poster.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.magelang.p2.3.poster. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text Borobudur temple at sunrise, a world heritage site

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.magelang.p6.3.poster — library.magelang.p6.3.poster

File: assets/pustaka/library.magelang.p6.3.poster.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.magelang.p6.3.poster. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a line of Topeng Ireng dancers with colourful feather headdresses performing at a village festival

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.wonosobo.p7.1.poster — library.wonosobo.p7.1.poster

File: assets/pustaka/library.wonosobo.p7.1.poster.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.wonosobo.p7.1.poster. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a bundengan, a woven bamboo duck-herder's hood turned into a plucked string instrument, resting on a mat

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.wonosobo.p8.1.poster — library.wonosobo.p8.1.poster

File: assets/pustaka/library.wonosobo.p8.1.poster.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.wonosobo.p8.1.poster. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text the Dieng Culture Festival at dusk with paper lanterns rising over the Arjuna temples, no identifiable faces

COMPOSITION AND DELIVERY
Target production canvas: 1280 × 720 pixels; aspect ratio 16:9. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.temanggung.p7.1 — Parakan, Kota Bambu Runcing

File: assets/pustaka/library.temanggung.p7.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.temanggung.p7.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text a quiet street of old heritage houses and shophouses in the town of Parakan in the morning, a symbolic bundle of sharpened bamboo spears tied with a red-and-white ribbon displayed respectfully in front, no people

COMPOSITION AND DELIVERY
Target production canvas: 960 × 640 pixels; aspect ratio 3:2. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.temanggung.p9.1 — Rasa Temanggung

File: assets/pustaka/library.temanggung.p9.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.temanggung.p9.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text food illustration on a woven bamboo table: a plate of kupat tahu with peanut sauce, a plate of crispy fried uceng fish, and a bowl of spicy mangut beong

COMPOSITION AND DELIVERY
Target production canvas: 960 × 640 pixels; aspect ratio 3:2. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.temanggung.p10.1 — Tips Jaka: Membaca Informasi Tersurat

File: assets/pustaka/library.temanggung.p10.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.temanggung.p10.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow sitting at a bamboo table, reading a short paper text and pointing at one line with his finger, a magnifying glass beside him, four small step symbols floating around him: an eye, a magnifier, a pointing finger and a check mark, no letters

COMPOSITION AND DELIVERY
Target production canvas: 960 × 640 pixels; aspect ratio 3:2. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.magelang.p8.1 — Prasasti Canggal dan Awal Mataram Kuno

File: assets/pustaka/library.magelang.p8.1.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as library.magelang.p8.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
If no suitable licensed photograph is available, create an explicitly labelled illustration of an ancient grey stone inscription slab inside a museum display case. Use a supplied verified photograph of the Canggal inscription to preserve the actual slab shape and placement. Keep the worn carved script unreadable; do not invent legible Pallava writing. Soft museum light, factual presentation, no people or interface. A generated illustration must never be presented as an archival photograph.

COMPOSITION AND DELIVERY
Target production canvas: 960 × 640 pixels; aspect ratio 3:2. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.magelang.p10.1 — Tips Jaka: Fakta, Pendapat, dan Menghubungkan Informasi

File: assets/pustaka/library.magelang.p10.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.magelang.p10.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow holding two cards, one showing a magnifier with a check mark symbol and the other a speech bubble with a small heart symbol, a picture and a page of text laid side by side on the table, no letters

COMPOSITION AND DELIVERY
Target production canvas: 960 × 640 pixels; aspect ratio 3:2. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.wonosobo.p5.1 — Embun Upas, Es di Pulau Tropis

File: assets/pustaka/library.wonosobo.p5.1.webp

Style review: Tidak berlaku

TASK
Create one finished image for the GELITA asset identified as library.wonosobo.p5.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
If no suitable licensed photograph is available, create an explicitly labelled illustration of early-morning frost on grass and potato leaves on the Dieng plateau. Tiny white ice crystals, cold blue light and the first warm sunlight; the Arjuna temples faint in the mist only if a verified architectural reference is supplied. Show frost, not a snow-covered landscape. No text or identifiable people. Do not present generated artwork as documentary evidence.

COMPOSITION AND DELIVERY
Target production canvas: 960 × 640 pixels; aspect ratio 3:2. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

---

## library.wonosobo.p10.1 — Tips Jaka: Cek Dulu Sebelum Percaya dan Berbagi

File: assets/pustaka/library.wonosobo.p10.1.webp

Style review: Belum sesuai

CURRENT APPROVED ART DIRECTION (2026-10-11)
Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture.
Jaka must match reference.01: approximately 11-year-old Javanese boy, tousled dark-brown hair with cowlick, brown eyes, cream short-sleeved shirt, RED SCARF, brown knee-length shorts, orange-brown batik waist cloth, sandals and brown leather backpack. No lurik shirt, iket/headwrap or blue vest on Jaka.
Preserve the subject and functional requirements below. For Mbah Kedu use reference.02; the red scarf applies only to Jaka.

TASK
Create one finished image for the GELITA asset identified as library.wonosobo.p10.1. Follow the brief below.

REFERENCE USE
If a reference is supplied, use it for the specifically described identity or real-world form. For character frames, attach the approved character sheet and frame 1. For heritage architecture and cultural objects, attach a verified photo; do not invent unseen factual details.

VISUAL BRIEF
storybook illustration for an Indonesian children's educational game (ages 8–14), Premium stylized 3D animated adventure game rendering, dimensional materials, soft cinematic lighting, warm lantern gold and deep navy, culturally respectful Kedu setting. No painted gouache or paper texture., clean readable silhouettes, gentle volumetric light, Central Javanese Kedu highlands, warm lantern-gold highlights (#DFC087, #F0DFB8) against deep night navy and twilight blue (#0B1320, #1B2740, #26355A), earthy browns (#4A3218, #8A6A32), soft blue-grey mist, calm and hopeful mood, culturally respectful, no text full-body character, three-quarter view facing screen right, standing on an invisible ground line near the bottom, whole figure visible including feet and headwear with even side margins, soft warm key light from the upper left and a faint cool rim light from the right, clean dimensional edges suitable for a cut-out, no scenery, no cast shadow looking thoughtfully at a smartphone, four small symbols floating around him: an official building, a clock, a magnifier and a shield, the phone screen shows only abstract shapes

COMPOSITION AND DELIVERY
Target production canvas: 960 × 640 pixels; aspect ratio 3:2. Compose for this ratio with the complete subject inside the canvas. These are delivery specifications; check the generated file dimensions and crop or resize carefully during post-production without stretching. Use an opaque image background unless the design brief explicitly requires transparency.

CONSTRAINTS
text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow

Negative: text, letters, numbers, writing, caption, watermark, signature, logo, user interface, frame, border, photorealistic, photograph, plastic look, anime, chibi, manga, horror, creepy, gore, blood, weapon pointed at viewer, smoking, cigarette, alcohol, neon colours, oversaturated, harsh black shadows, blurry, low resolution, jpeg artifacts, deformed hands, extra fingers, extra limbs, duplicate, cropped subject, European castle, Chinese or Japanese architecture, snow